<?php

namespace app\helpers;

class Validador {

    private array $erros = [];

    public function Obrigatorio(string $campo, mixed $valor, ?string $mensagem){

        if(empty($valor) && $valor !== '0'){

            $this->erros['campo'] = $mensagem ?? "O campo {$campo} é obrigatório.";

        }

        return $this;

    }

    public function temErros() : bool{

        return !empty($this->erros);

    }

    public function getErros(){

        

    }

}