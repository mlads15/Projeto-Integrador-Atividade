<?php

namespace app\controllers;

use app\core\Controller;
use app\models\Usuario;
use app\services\UsuarioService;

class UsuarioController extends Controller
{
    private UsuarioService $service;

    public function __construct() {
        $this->service = new UsuarioService();
    }

    public function index() {
        $data['usuarios'] = $this->service->getUsuarios();
        $this->view('usuarios/usuario_list', $data);
    }

    public function cadastrar() {
        $this->view('usuarios/usuario_create');
    }

    public function getUsuarioById(int $id) {
        $sql = "SELECT id, nome_usuario as nomeUsuario, email, perfil FROM usuarios WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':id', $id);
        $stmt->execute();
        return $stmt->fetch();
    }

    public function updateUsuario(Usuario $usuario): bool {
        $sql = "UPDATE usuarios SET nome_usuario = :nome, email = :email, perfil = :perfil WHERE id = :id";
        $stmt = $this->connection->prepare($sql);
        $stmt->bindValue(':nome', $usuario->getNomeUsuario());
        $stmt->bindValue(':email', $usuario->getEmail());
        $stmt->bindValue(':perfil', $usuario->getPerfil());
        $stmt->bindValue(':id', $usuario->getId());
        return $stmt->execute();
    }

    public function editar() {
    $id = $_GET['id'];
    $data['usuario'] = $this->service->getUsuarioById($id);
    $this->view('usuarios/usuario_edit', $data);
    }

    public function atualizar() {
        $usuario = new Usuario(
            $_POST['id'], 
            $_POST['nomeUsuario'], 
            $_POST['email'], 
            $_POST['senha'] ?? '', 
            $_POST['perfil']
        );
        $this->service->updateUsuario($usuario);
        $this->redirect(URL_BASE . '/usuarios');
    }

    public function excluir() {
    $id = $_GET['id'];
    $this->service->deleteUsuario($id);
    $this->redirect(URL_BASE . '/usuarios');
    }

    public function salvar() {

        $nomeUsuario = $_POST['nomeUsuario'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        $perfil = $_POST['perfil'];

        //validar

        //salvar

    $usuario = new Usuario(
        0, 
        $_POST['nomeUsuario'], 
        $_POST['email'], 
        $_POST['senha'], 
        $_POST['perfil']
    );

    if ($this->service->saveUsuario($usuario)) {
        $this->redirect(URL_BASE . '/usuarios');
    } else {
        // Aqui você poderia passar uma mensagem de erro para a view
        echo "Erro: Este e-mail já está cadastrado!";
    }
    }

}